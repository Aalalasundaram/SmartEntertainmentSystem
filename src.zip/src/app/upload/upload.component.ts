import { Component, OnInit } from '@angular/core';
import {
  FormBuilder,
  FormGroup,
  FormControl,
  Validators
} from '@angular/forms';

@Component({
  selector: 'app-upload-form',
  templateUrl: './upload.component.html',
  styleUrls: ['./upload.component.css']
})
export class UploadComponent implements OnInit {
  uploadForm: FormGroup;
  constructor(private formBuiler: FormBuilder) {}
  isCatSelected = false;
  selectedCat = '';

  types = {
    audio: ['mp3', 'aac', 'wav'],
    video: ['mp4', 'avi', 'mkv']
  };
  ngOnInit() {
    this.uploadForm = this.formBuiler.group({
      selectedCat: ['What you want to upload', Validators.required],
      selectedSubCat: ['', Validators.required],
      selectedFile: ['', Validators.required],
      tags: ['', Validators.required]
    });
  }

  populateSubcat() {
    this.isCatSelected = true;
    this.selectedCat = this.uploadForm.value.selectedCat;
    console.log(this.uploadForm);
  }
  submitForm(e) {
    e.preventDefault();
    console.log(this.uploadForm.value);
  }
}
