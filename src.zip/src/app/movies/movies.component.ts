import { Component, OnInit, ViewChild } from '@angular/core';
import { MoviesService } from './movies.service';

@Component({
  selector: 'app-movies',
  templateUrl: './movies.component.html',
  styleUrls: ['./movies.component.css']
})
export class MoviesComponent implements OnInit {

  moviesList: any[];

  constructor(private moviesService: MoviesService) { }

  ngOnInit() {
    this.getMoviesList();
  }

//   @ViewChild('videoPlayer') videoplayer: any;
// videoUrl: string = '/cma/contentmanager/getfragment?fragmentid=';
// videoSource: any;

// private loadVideo(id) {
//         this.moviesService.getVideo(this.videoUrl+''+id) // get video for fragment from secure API
//             .subscribe(data => {
//                 this.videoSource = data;
//             })
// }

  getMoviesList(): void {
    this.moviesList = this.moviesService.getMoviesList();
  }

}
